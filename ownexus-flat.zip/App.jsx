import React, { useState, useMemo } from "react";

/* ═══════════ SIGIL GENERATOR (deterministic per hero) ═══════════
   Procedural sacred-geometry seal from hero name + role color.
   Swap in real art later via ART["Genji"] = "/heroes/genji.png" (renders <img> instead). */
function hashStr(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function gcdN(a,b){while(b){const t=b;b=a%b;a=t;}return a;}
const mixC=(c,d,t)=>c.map((x,i)=>Math.round(x+(d[i]-x)*t));
const TAU=Math.PI*2, sf=(n)=>Math.round(n*100)/100, ppt=(cx,cy,r,a)=>[cx+r*Math.cos(a),cy+r*Math.sin(a)];
const ART = {};
function sigilShapes(name, rgb){
  const R=mulberry32(hashStr(name)), fid="sg"+hashStr(name);
  const acc=rgb, hi=mixC(rgb,[255,255,255],0.45), dim=mixC(rgb,[10,12,16],0.5), deep=mixC(rgb,[8,9,13],0.7);
  const col=(c,o)=>`rgba(${c[0]},${c[1]},${c[2]},${o})`;
  const sides=3+Math.floor(R()*6), rot=R()*TAU, Rp=29;
  const verts=[...Array(sides)].map((_,i)=>ppt(50,50,Rp,rot+i*TAU/sides));
  const sh=[]; const add=(type,attr)=>sh.push({type,attr});
  add("circle",{cx:50,cy:50,r:30,fill:col(acc,0.12),filter:`url(#${fid})`});
  add("circle",{cx:50,cy:50,r:47,fill:"none",stroke:col(dim,0.5),strokeWidth:0.7});
  add("circle",{cx:50,cy:50,r:44.2,fill:"none",stroke:col(acc,0.55),strokeWidth:0.7});
  const ticks=[32,36,40,44,48][Math.floor(R()*5)], tickDots=R()>0.5;
  for(let i=0;i<ticks;i++){const a=i*TAU/ticks;
    if(tickDots){const p=ppt(50,50,46,a);add("circle",{cx:sf(p[0]),cy:sf(p[1]),r:0.5,fill:col(acc,0.6)});}
    else{const p1=ppt(50,50,44.5,a),p2=ppt(50,50,47.5,a);add("line",{x1:sf(p1[0]),y1:sf(p1[1]),x2:sf(p2[0]),y2:sf(p2[1]),stroke:col(acc,0.5),strokeWidth:0.6});}}
  add("circle",{cx:50,cy:50,r:37,fill:"none",stroke:col(dim,0.45),strokeWidth:0.6,...(R()>0.5?{strokeDasharray:"2 2.5"}:{})});
  for(const v of verts){const i=ppt(50,50,9,Math.atan2(v[1]-50,v[0]-50));add("line",{x1:sf(i[0]),y1:sf(i[1]),x2:sf(v[0]),y2:sf(v[1]),stroke:col(acc,0.3),strokeWidth:0.5});}
  add("polygon",{points:verts.map(v=>`${sf(v[0])},${sf(v[1])}`).join(" "),fill:col(acc,0.05),stroke:col(acc,0.85),strokeWidth:1});
  const ks=[]; for(let k=2;k<=Math.floor(sides/2);k++) if(gcdN(k,sides)===1) ks.push(k);
  if(ks.length&&R()>0.25){const k=ks[Math.floor(R()*ks.length)];const order=[];let idx=0;do{order.push(idx);idx=(idx+k)%sides;}while(idx!==0);
    const d="M"+order.map(i=>`${sf(verts[i][0])} ${sf(verts[i][1])}`).join(" L")+" Z";
    add("path",{d,fill:"none",stroke:col(hi,0.9),strokeWidth:1.1,strokeLinejoin:"round"});
  } else {const v2=[...Array(sides)].map((_,i)=>ppt(50,50,Rp,rot+TAU/(sides*2)+i*TAU/sides));
    add("polygon",{points:v2.map(v=>`${sf(v[0])},${sf(v[1])}`).join(" "),fill:"none",stroke:col(acc,0.5),strokeWidth:0.8});}
  const chords=Math.floor(R()*3);
  for(let i=0;i<chords;i++){const a=R()*TAU,b=a+Math.PI*(0.5+R()*0.6);const p1=ppt(50,50,Rp,a),p2=ppt(50,50,Rp,b);add("line",{x1:sf(p1[0]),y1:sf(p1[1]),x2:sf(p2[0]),y2:sf(p2[1]),stroke:col(acc,0.22),strokeWidth:0.5});}
  add("circle",{cx:50,cy:50,r:13,fill:col(deep,0.6),stroke:col(acc,0.7),strokeWidth:0.7});
  const cs=3+Math.floor(R()*4),crot=R()*TAU;const cv=[...Array(cs)].map((_,i)=>ppt(50,50,7,crot+i*TAU/cs));
  add("polygon",{points:cv.map(v=>`${sf(v[0])},${sf(v[1])}`).join(" "),fill:col(acc,0.85),stroke:col(hi,0.9),strokeWidth:0.6});
  add("circle",{cx:50,cy:50,r:2.4,fill:col(hi,0.95)});
  const sat=3+Math.floor(R()*5),off=R()*TAU;
  for(let i=0;i<sat;i++){const a=off+i*TAU/sat+(R()-0.5)*0.2;const p=ppt(50,50,44.2,a);
    add("circle",{cx:sf(p[0]),cy:sf(p[1]),r:1.6,fill:col(hi,0.95)});
    add("circle",{cx:sf(p[0]),cy:sf(p[1]),r:2.8,fill:"none",stroke:col(acc,0.55),strokeWidth:0.5});}
  return {fid, shapes:sh};
}
function Sigil({ name, rgb, size = 40 }){
  if(ART[name]) return <img src={ART[name]} alt={name} width={size} height={size} style={{borderRadius:"50%",objectFit:"cover",display:"block",flexShrink:0}} />;
  const { fid, shapes } = useMemo(()=>sigilShapes(name, rgb), [name, rgb[0], rgb[1], rgb[2]]);
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} style={{display:"block",flexShrink:0}}>
      <defs><filter id={fid} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3.2"/></filter></defs>
      {shapes.map((s,i)=>React.createElement(s.type,{key:i,...s.attr}))}
    </svg>
  );
}

/* ════════════════════════ DATA ════════════════════════ */
const FK = ["hp","speed","vert","ult","space","dura","burst","range","skill"];
const FLABEL = { hp:"HP", speed:"SPD", vert:"VERT", ult:"ULT", space:"ZONE", dura:"DURA", burst:"BRST", range:"RNG", skill:"SKL" };

const SCORES = [
  ["D.Va","Tank",8,6,8,9,6,9,6,5,7],["Reinhardt","Tank",9,4,1,8,8,8,5,2,5],
  ["Winston","Tank",8,7,8,5,5,7,3,3,7],["Zarya","Tank",8,4,1,9,5,8,7,3,6],
  ["Roadhog","Tank",9,4,1,6,6,8,8,5,5],["Sigma","Tank",8,4,3,8,8,8,6,5,6],
  ["Orisa","Tank",9,4,1,7,8,8,5,5,4],["Wrecking Ball","Tank",8,8,7,6,7,8,4,3,9],
  ["Doomfist","Tank",7,8,7,7,8,7,7,3,9],["Junker Queen","Tank",8,5,1,7,7,7,6,4,6],
  ["Ramattra","Tank",8,4,1,8,8,8,5,4,6],["Mauga","Tank",9,5,1,6,6,8,7,5,4],
  ["Genji","DPS",3,8,7,8,4,7,7,4,10],["Tracer","DPS",2,10,4,7,3,8,7,3,9],
  ["Reaper","DPS",4,5,4,7,4,8,9,2,3],["Cassidy","DPS",4,5,1,5,6,5,8,6,6],
  ["Soldier: 76","DPS",4,6,1,6,4,6,5,6,4],["Pharah","DPS",4,6,10,6,6,5,7,6,7],
  ["Junkrat","DPS",4,5,5,8,9,5,8,5,5],["Mei","DPS",5,4,4,8,10,8,7,4,6],
  ["Hanzo","DPS",4,5,7,7,7,5,10,8,9],["Widowmaker","DPS",3,5,8,3,4,4,10,10,10],
  ["Ashe","DPS",4,5,4,6,6,5,8,8,6],["Bastion","DPS",5,4,3,6,7,6,8,6,4],
  ["Symmetra","DPS",4,5,3,4,7,5,6,4,5],["Torbjörn","DPS",5,4,1,6,8,7,7,5,4],
  ["Sombra","DPS",4,7,5,6,5,8,6,4,8],["Echo","DPS",3,7,9,8,4,6,8,6,9],
  ["Sojourn","DPS",4,7,6,6,5,5,8,7,8],["Venture","DPS",5,7,6,6,6,7,7,4,7],
  ["Mercy","Support",4,7,9,5,1,8,1,4,6],["Ana","Support",4,4,1,9,7,4,4,8,9],
  ["Lúcio","Support",4,8,6,8,6,7,3,4,8],["Zenyatta","Support",4,4,1,8,6,4,7,7,7],
  ["Moira","Support",4,6,4,6,4,9,5,4,2],["Brigitte","Support",5,5,1,6,7,8,4,2,4],
  ["Baptiste","Support",4,5,6,7,5,7,6,6,7],["Kiriko","Support",4,7,7,8,5,8,7,5,8],
  ["Illari","Support",4,6,6,7,6,6,7,7,7],["Lifeweaver","Support",5,5,6,5,6,7,3,5,6],
  ["Juno","Support",4,8,8,7,5,6,6,6,6],["Mizuki","Support",3,7,5,5,6,7,6,5,8],
  // ── 2026 additions (educated estimates — kits researched, scores by comparison) ──
  ["Vendetta","DPS",5,9,7,7,5,7,8,2,9],["Sierra","DPS",4,7,8,6,5,5,9,8,7],
  ["Emre","DPS",5,6,2,7,4,7,6,7,6],["Anran","DPS",4,8,6,7,5,7,7,4,7],
  ["Freja","DPS",4,7,7,6,5,5,8,7,8],["Domina","Tank",8,4,1,6,8,8,6,9,6],
  ["Jetpack Cat","Support",3,9,9,6,5,6,4,5,8],["Wuyang","Support",4,7,5,7,5,7,5,6,7],
];
const META = {
  "D.Va":{s:["Dive","Poke"],t:["diveTank","comboUlt"]},"Reinhardt":{s:["Brawl"],t:["setup","brawlTankPure"]},
  "Winston":{s:["Dive"],t:["diveTank"]},"Zarya":{s:["Brawl","Poke"],t:["setup"]},
  "Roadhog":{s:["Brawl"],t:["brawlTankPure"]},"Sigma":{s:["Poke","Brawl"],t:["setup"]},
  "Orisa":{s:["Brawl","Poke"],t:[]},"Wrecking Ball":{s:["Dive"],t:["diveTank"]},
  "Doomfist":{s:["Dive"],t:["diveTank"]},"Junker Queen":{s:["Brawl"],t:["brawlTankPure"]},
  "Ramattra":{s:["Brawl","Poke"],t:["setup"]},"Mauga":{s:["Brawl"],t:["brawlTankPure"]},
  "Genji":{s:["Dive"],t:["comboUlt","burstDPS"]},"Tracer":{s:["Dive"],t:["comboUlt","burstDPS"]},
  "Reaper":{s:["Brawl"],t:["comboUlt"]},"Cassidy":{s:["Brawl","Poke"],t:["setup","comboUlt","burstDPS"]},
  "Soldier: 76":{s:["Poke","Brawl"],t:["comboUlt"]},"Pharah":{s:["Poke"],t:["flyer","comboUlt"]},
  "Junkrat":{s:["Brawl"],t:["comboUlt"]},"Mei":{s:["Brawl"],t:["setup","comboUlt"]},
  "Hanzo":{s:["Poke"],t:["sniper","burstDPS","comboUlt"]},"Widowmaker":{s:["Poke"],t:["sniper","burstDPS"]},
  "Ashe":{s:["Poke"],t:["sniper","burstDPS"]},"Bastion":{s:["Poke"],t:["anchorDPS","comboUlt"]},
  "Symmetra":{s:["Brawl"],t:["anchorDPS"]},"Torbjörn":{s:["Poke","Brawl"],t:["anchorDPS"]},
  "Sombra":{s:["Dive"],t:["hackSetup"]},"Echo":{s:["Poke","Dive"],t:["flyer","comboUlt","burstDPS"]},
  "Sojourn":{s:["Poke","Dive"],t:["burstDPS"]},"Venture":{s:["Dive","Brawl"],t:[]},
  "Mercy":{s:["Dive","Poke"],t:["pocketHealer","damageAmp","lowPressure"]},
  "Ana":{s:["Poke","Brawl"],t:["setup","airSupport","burstHeal","damageAmp","immobileSupport","peelSupport"]},
  "Lúcio":{s:["Dive","Brawl"],t:["speedEnable","peelSupport"]},"Zenyatta":{s:["Poke"],t:["damageAmp","immobileSupport"]},
  "Moira":{s:["Brawl","Dive"],t:["lowPressure","peelSupport"]},"Brigitte":{s:["Brawl"],t:["peelSupport"]},
  "Baptiste":{s:["Poke","Brawl"],t:["airSupport","burstHeal"]},"Kiriko":{s:["Dive","Brawl"],t:["burstHeal","peelSupport"]},
  "Illari":{s:["Poke"],t:[]},"Lifeweaver":{s:["Brawl","Poke"],t:["burstHeal","lowPressure","peelSupport"]},
  "Juno":{s:["Dive","Poke"],t:["airSupport"]},"Mizuki":{s:["Brawl","Dive"],t:["peelSupport"]},
  "Vendetta":{s:["Dive"],t:["burstDPS"]},"Sierra":{s:["Poke","Dive"],t:["sniper","burstDPS"]},
  "Emre":{s:["Poke","Brawl"],t:["comboUlt"]},"Anran":{s:["Dive","Brawl"],t:["burstDPS"]},
  "Freja":{s:["Poke","Dive"],t:["sniper","burstDPS"]},"Domina":{s:["Poke","Brawl"],t:["setup"]},
  "Jetpack Cat":{s:["Dive","Brawl"],t:["peelSupport"]},"Wuyang":{s:["Brawl","Poke"],t:["burstHeal"]},
};
const HEROES = {}; const BY_ROLE = { Tank:[], DPS:[], Support:[] };
for (const r of SCORES){ const [name,role,...n]=r; const sc={}; FK.forEach((k,i)=>sc[k]=n[i]);
  HEROES[name]={name,role,scores:sc,styles:META[name].s,traits:META[name].t}; BY_ROLE[role].push(name); }
Object.values(BY_ROLE).forEach(a=>a.sort());

const ROLE_C = { Tank:[96,165,250], DPS:[248,113,113], Support:[52,211,153] };
const TIER_C = { S:[251,191,36], A:[52,211,153], B:[96,165,250], C:[245,158,11], D:[248,113,113] };
const VERD_C = { "FAVORED":[52,211,153], "SLIGHT EDGE":[110,231,183], "EVEN":[148,156,168], "SLIGHT DISADVANTAGE":[245,158,11], "UNFAVORED":[248,113,113] };

/* ── official 2026 sub-role system (Reign of Talon) ── */
const SUBROLES = {
  Bruiser:    { role:"Tank", passive:"Takes −25% critical damage; +20% move speed at critical HP.", blurb:"Front-line tanks that face the enemy tank head-on with high close-range damage and heavy sustain.", heroes:["Mauga","Orisa","Roadhog","Zarya"] },
  Initiator:  { role:"Tank", passive:"Staying airborne heals you (~+75 HP after 0.8s aloft).", blurb:"Dive tanks that start the fight from the air and crash into the backline.", heroes:["D.Va","Doomfist","Winston","Wrecking Ball"] },
  Stalwart:   { role:"Tank", passive:"40% knockback & slow resistance.", blurb:"Immovable anchors that hold space and shrug off displacement.", heroes:["Domina","Junker Queen","Ramattra","Reinhardt","Sigma"] },
  Flanker:    { role:"DPS", passive:"Health packs restore +75 extra health.", blurb:"Mobile assassins that slip into the backline and pick off vulnerable targets.", heroes:["Anran","Genji","Reaper","Tracer","Vendetta","Venture"] },
  Recon:      { role:"DPS", passive:"Damaging an enemy below 50% HP reveals them through walls for 5s.", blurb:"Scouts and aerial threats that gather info and punish weakened enemies.", heroes:["Echo","Freja","Pharah","Sombra","Sierra"] },
  Sharpshooter:{ role:"DPS", passive:"Critical hits reduce your movement-ability cooldowns.", blurb:"Precision range dealers rewarded for landing crits.", heroes:["Ashe","Cassidy","Hanzo","Sojourn","Widowmaker"] },
  Specialist: { role:"DPS", passive:"Eliminations briefly grant +50% reload speed (3s).", blurb:"Tools-and-zoning damage that lock down space and snowball kills.", heroes:["Bastion","Emre","Junkrat","Mei","Soldier: 76","Symmetra","Torbjörn"] },
  Medic:      { role:"Support", passive:"Healing allies with your weapon also heals you (25%).", blurb:"Dedicated healers whose primary job is keeping allies alive.", heroes:["Kiriko","Lifeweaver","Mercy","Moira"] },
  Survivor:   { role:"Support", passive:"Using a movement ability starts passive health regen.", blurb:"Squishy but slippery supports who escape, heal up, and re-engage.", heroes:["Brigitte","Illari","Juno","Mizuki","Wuyang"] },
  Tactician:  { role:"Support", passive:"Store up to 25% excess ultimate charge after using your ult.", blurb:"Utility supports who swing fights with debuffs, buffs, and big ults.", heroes:["Ana","Baptiste","Jetpack Cat","Lúcio","Zenyatta"] },
};
const SUBROLE_OF = {}; for (const [k,v] of Object.entries(SUBROLES)) v.heroes.forEach(h=>SUBROLE_OF[h]=k);
const SUBROLE_ORDER = ["Bruiser","Initiator","Stalwart","Flanker","Recon","Sharpshooter","Specialist","Medic","Survivor","Tactician"];
const archetypeOf = (h)=> h.styles.length===1 ? h.styles[0] : h.styles.join("-");

/* ── ultimate names (for combo chains) ── */
const ULT = {
  "D.Va":"Self-Destruct","Reinhardt":"Earthshatter","Winston":"Primal Rage","Zarya":"Graviton Surge","Roadhog":"Whole Hog",
  "Sigma":"Gravitic Flux","Orisa":"Terra Surge","Wrecking Ball":"Minefield","Doomfist":"Meteor Strike","Junker Queen":"Rampage",
  "Ramattra":"Annihilation","Mauga":"Cage Fight","Domina":"Panopticon",
  "Genji":"Dragonblade","Tracer":"Pulse Bomb","Reaper":"Death Blossom","Cassidy":"Deadeye","Soldier: 76":"Tactical Visor",
  "Pharah":"Barrage","Junkrat":"RIP-Tire","Mei":"Blizzard","Hanzo":"Dragonstrike","Widowmaker":"Infra-Sight","Ashe":"B.O.B.",
  "Bastion":"Artillery","Symmetra":"Photon Barrier","Torbjörn":"Molten Core","Sombra":"EMP","Echo":"Duplicate","Sojourn":"Overclock",
  "Venture":"Tectonic Shock","Vendetta":"Sundering Blade","Emre":"Override Protocol","Anran":"Vermillion Ascent",
  "Mercy":"Valkyrie","Ana":"Nano Boost","Lúcio":"Sound Barrier","Zenyatta":"Transcendence","Moira":"Coalescence","Brigitte":"Rally",
  "Baptiste":"Amplification Matrix","Kiriko":"Kitsune Rush","Illari":"Captive Sun","Lifeweaver":"Tree of Life","Juno":"Orbital Ray",
};
const ultName=(n)=>ULT[n]||"Ultimate";
const ANCHORS = [["Zarya","Graviton Surge"],["Sigma","Gravitic Flux"],["Reinhardt","Earthshatter"],["Mei","Blizzard"],["Sombra","EMP"]];
const ANCHOR_NOTE = {
  Zarya:"Graviton clusters the enemy; the follow-up ult wipes the held group.",
  Sigma:"Flux lifts and slams the group, setting up an AoE finisher.",
  Reinhardt:"Earthshatter stuns the line — pile on damage before they recover.",
  Mei:"Blizzard freezes the group for a guaranteed follow-up.",
  Sombra:"EMP strips shields and HP; convert the chaos with a burst ult.",
};
const NANO_TARGETS = new Set(["Genji","Doomfist","Reaper","Winston","Mauga","Junker Queen","Vendetta","Anran","Ramattra","Reinhardt"]);
const MERCY_TARGETS = new Set(["Pharah","Echo","Bastion","Soldier: 76","Ashe","Widowmaker","Sojourn","Hanzo"]);
const SPEED_TARGETS = new Set(["Winston","D.Va","Doomfist","Wrecking Ball","Reinhardt","Junker Queen","Mauga"]);

const has=(h,t)=>h.traits.includes(t);
const comp=(h)=>FK.reduce((a,k)=>a+h.scores[k],0)/FK.length;

const PRESETS = {
  Dive:["Winston","Genji","Tracer","Lúcio","Kiriko"], Brawl:["Mauga","Reaper","Mei","Lúcio","Kiriko"],
  Poke:["Sigma","Ashe","Widowmaker","Ana","Baptiste"], Pharmercy:["D.Va","Pharah","Echo","Mercy","Baptiste"],
};

/* counter sets */
const S=(a)=>new Set(a);
const ANTI_AIR=S(["Cassidy","Ashe","Soldier: 76","Sojourn","Widowmaker","Echo","Hanzo","Sierra","Emre"]);
const ANTI_DIVE=S(["Brigitte","Mei","Zarya","Cassidy","Ana","Moira","Kiriko","Roadhog","Junkrat","Domina"]);
const FLYER=S(["Pharah","Echo"]);
const ANTI_HEAL=S(["Ana","Junker Queen"]);
const BARRIER=S(["Reinhardt","Sigma","Orisa","Ramattra","Domina"]);
const BARRIER_BREAK=S(["Reaper","Bastion","Symmetra","Mauga","Zarya","Sigma","Vendetta"]);
const OVERHEALTH=S(["Mauga","Roadhog","Junker Queen"]);
const DIVE_HERO=S(["Winston","Wrecking Ball","Doomfist","D.Va","Genji","Tracer","Sombra","Vendetta","Anran"]);
const BEATS={Dive:"Poke",Poke:"Brawl",Brawl:"Dive"};

/* ════════════════════════ ENGINES ════════════════════════ */
function identity(names){
  const team=names.filter(Boolean);
  if(team.length<3) return null;
  const tank=team.find(n=>HEROES[n].role==="Tank");
  if(tank) return HEROES[tank].styles[0];
  const styles=["Dive","Brawl","Poke"];
  const cnt=Object.fromEntries(styles.map(x=>[x,team.filter(n=>HEROES[n].styles.includes(x)).length]));
  return styles.slice().sort((a,b)=>cnt[b]-cnt[a])[0];
}

function analyze(names){
  const sel=names.filter(Boolean).map(n=>HEROES[n]);
  const dps=sel.filter(h=>h.role==="DPS"), sup=sel.filter(h=>h.role==="Support"), tank=sel.find(h=>h.role==="Tank");
  const log=[]; const add=(kind,pts,label,reason)=>log.push({kind,pts,label,reason});
  const pairs=[]; for(let i=0;i<sel.length;i++)for(let j=i+1;j<sel.length;j++)pairs.push([sel[i],sel[j]]);
  for(const [a,b] of pairs){ const A=[a,b];
    const fl=A.find(h=>has(h,"flyer")), pk=A.find(h=>has(h,"pocketHealer"));
    if(fl&&pk&&fl!==pk) add("syn",5,"Pocketed air threat",`${pk.name} boosting ${fl.name} is a hard-to-punish flying carry.`);
    const air=A.find(h=>has(h,"airSupport"));
    if(fl&&air&&fl!==air) add("syn",2,"Air support",`${air.name} can sustain ${fl.name} at altitude.`);
    const su=A.find(h=>has(h,"setup")), pay=A.find(h=>has(h,"comboUlt"));
    if(su&&pay&&su!==pay) add("syn",3,"Ult-combo line",`${su.name}'s setup chains into ${pay.name}'s payoff ultimate.`);
    const amp=A.find(h=>has(h,"damageAmp")), ca=A.find(h=>has(h,"burstDPS"));
    if(amp&&ca&&amp!==ca) add("syn",3,"Amplified carry",`${amp.name} turns ${ca.name} into a one-shot threat.`);
    const sp=A.find(h=>has(h,"speedEnable")), tk=A.find(h=>h.role==="Tank"&&(h.styles.includes("Dive")||h.styles.includes("Brawl")));
    if(sp&&tk&&sp!==tk) add("syn",3,"Speed engage",`${sp.name}'s speed powers ${tk.name}'s commit.`);
    const hk=A.find(h=>has(h,"hackSetup")), dv=A.find(h=>has(h,"diveTank")||(h.role==="DPS"&&h.styles.includes("Dive")));
    if(hk&&dv&&hk!==dv) add("syn",2,"Hack-assisted dive",`${hk.name} neutralizes a target for ${dv.name}.`);
    const sn=A.find(h=>has(h,"sniper")), bt=A.find(h=>has(h,"brawlTankPure"));
    if(sn&&bt) add("anti",-3,"Sniper / brawl clash",`${sn.name} wants range, but ${bt.name} forces close fights.`);
    const an=A.find(h=>has(h,"anchorDPS")), d2=A.find(h=>has(h,"diveTank"));
    if(an&&d2) add("anti",-3,"Anchor / dive clash",`${an.name} is stationary while ${d2.name} dives.`);
    const f2=A.find(h=>has(h,"flyer")), b2=A.find(h=>has(h,"brawlTankPure"));
    if(f2&&b2) add("anti",-2,"Air / brawl mismatch",`${f2.name} gains little from ${b2.name}'s ground brawl.`);
  }
  if(tank&&has(tank,"diveTank")) for(const s of sup) if(has(s,"peelSupport")) add("syn",2,"Backline peel",`${s.name} protects the backline while ${tank.name} dives.`);
  if(sup.length===2&&sup.every(s=>has(s,"burstHeal"))) add("syn",2,"Resilient heal core",`${sup[0].name} + ${sup[1].name} stack strong burst healing.`);
  if(sup.length===2&&sup.every(s=>has(s,"lowPressure"))) add("anti",-5,"Passive support pairing",`${sup[0].name} + ${sup[1].name}: little kill pressure or peel.`);
  if(sup.length===2&&!sup.some(s=>has(s,"burstHeal"))) add("anti",-3,"No burst healing",`Neither support can burst-save a focused teammate.`);
  if(tank&&has(tank,"diveTank")&&sup.length===2&&sup.every(s=>has(s,"immobileSupport"))) add("anti",-4,"Exposed backline",`Two immobile supports behind a dive tank are easy to collapse on.`);
  const snp=dps.filter(h=>has(h,"sniper")); if(snp.length===2) add("anti",-2,"Double sniper",`${snp[0].name} + ${snp[1].name}: thin frontline, low sustained pressure.`);

  let cohesion=null; const dom=identity(names);
  if(sel.length>=3&&dom){
    let cov, off;
    if(tank){ const pool=sel.filter(h=>h!==tank); const fits=pool.filter(h=>h.styles.some(st=>tank.styles.includes(st)));
      cov=pool.length?fits.length/pool.length:1; off=pool.filter(h=>!h.styles.some(st=>tank.styles.includes(st))).map(h=>h.name); }
    else { cov=sel.filter(h=>h.styles.includes(dom)).length/sel.length; off=sel.filter(h=>!h.styles.includes(dom)).map(h=>h.name); }
    if(cov>=0.8) add("syn",5,"Unified "+dom,`The team fits a ${dom} game plan around the tank.`);
    else if(cov>=0.55) add("syn",2,"Mostly "+dom, off.length?`Leans ${dom}; ${off.join(", ")} drifts off-plan.`:`Leans ${dom}.`);
    else if(cov<0.4) add("anti",-6,"Muddled identity",`No clear plan — ${off.join(", ")} clash with the ${dom} core.`);
    else add("anti",-2,"Loose identity",`Only a rough ${dom} lean.`);
    cohesion={dom,cov:Math.round(cov*100)};
  }
  const synergyTotal=log.reduce((a,e)=>a+e.pts,0);
  const power=sel.length?(sel.reduce((a,h)=>a+comp(h),0)/sel.length)*10:0;
  const rating=Math.max(0,Math.min(100,power+synergyTotal));
  const tier=rating>=80?"S":rating>=70?"A":rating>=58?"B":rating>=45?"C":"D";
  const axes=FK.map(k=>({k,v:sel.length?sel.reduce((a,h)=>a+h.scores[k],0)/sel.length:0}));
  log.sort((a,b)=>b.pts-a.pts);
  return {power,synergyTotal,rating,tier,cohesion,dom,axes,log,count:sel.length};
}

function csets(team){ return {
  antiAir:team.filter(n=>ANTI_AIR.has(n)), antiDive:team.filter(n=>ANTI_DIVE.has(n)),
  flyer:team.filter(n=>FLYER.has(n)), antiHeal:team.filter(n=>ANTI_HEAL.has(n)),
  barrier:team.filter(n=>BARRIER.has(n)), barrierBreak:team.filter(n=>BARRIER_BREAK.has(n)),
  overhealth:team.filter(n=>OVERHEALTH.has(n)), dive:team.filter(n=>DIVE_HERO.has(n)),
};}

function matchup(youN, enemyN){
  const you=youN.filter(Boolean), enemy=enemyN.filter(Boolean);
  const Y=csets(you), E=csets(enemy);
  const yd=identity(you), ed=identity(enemy);
  const edges=[]; const push=(pts,label,reason)=>edges.push({pts,label,reason});
  if(yd&&ed){
    if(BEATS[yd]===ed) push(7,"Comp triangle",`Your ${yd} naturally pressures their ${ed}.`);
    else if(BEATS[ed]===yd) push(-7,"Comp triangle",`Their ${ed} naturally pressures your ${yd}.`);
    else push(0,"Mirror band",`Both lean ${yd===ed?yd:yd+" / "+ed} — it comes down to execution.`);
  }
  if(E.dive.length){ if(Y.antiDive.length) push(4,"Anti-dive ready",`${Y.antiDive.join(", ")} can punish their dive (${E.dive.join(", ")}).`);
    else push(-6,"Open backline",`No anti-dive — their divers (${E.dive.join(", ")}) hit your backline freely.`); }
  if(Y.dive.length){ if(E.antiDive.length) push(-3,"Dive contested",`Their peel (${E.antiDive.join(", ")}) blunts your dive (${Y.dive.join(", ")}).`);
    else push(5,"Dive unanswered",`They can't peel — your dive (${Y.dive.join(", ")}) gets in freely.`); }
  if(E.flyer.length){ if(Y.antiAir.length) push(4,"Air covered",`${Y.antiAir.join(", ")} can shoot down their air (${E.flyer.join(", ")}).`);
    else push(-7,"Air unanswered",`No hitscan — their flyer (${E.flyer.join(", ")}) runs the game.`); }
  if(Y.flyer.length){ if(E.antiAir.length) push(-4,"Flyer grounded",`Their hitscan (${E.antiAir.join(", ")}) shuts down your air (${Y.flyer.join(", ")}).`);
    else push(5,"Air dominance",`They have no hitscan — your flyer (${Y.flyer.join(", ")}) runs free.`); }
  if(E.overhealth.length){ if(Y.antiHeal.length) push(3,"Anti-heal edge",`${Y.antiHeal.join(", ")} cuts their sustain tank (${E.overhealth.join(", ")}).`);
    else push(-3,"Sustain wall",`Their ${E.overhealth.join(", ")} is hard to break without anti-heal.`); }
  if(ed==="Poke"&&E.barrier.length){ if(Y.barrierBreak.length) push(2,"Shield break",`${Y.barrierBreak.join(", ")} cracks their poke barriers (${E.barrier.join(", ")}).`);
    else push(-2,"Stalled by shields",`Their barriers (${E.barrier.join(", ")}) stall you and you lack shield-break.`); }
  const edge=edges.reduce((a,e)=>a+e.pts,0);
  const verdict=edge>=9?"FAVORED":edge>=3?"SLIGHT EDGE":edge>-3?"EVEN":edge>-9?"SLIGHT DISADVANTAGE":"UNFAVORED";
  edges.sort((a,b)=>b.pts-a.pts);
  return {edge,verdict,yd,ed,edges};
}

/* ── pairwise synergy (for the relationship graph) ── */
function pairSynergy(a,b){
  const A=[a,b]; const out=[]; const add=(pts,label,reason)=>out.push({pts,label,reason});
  const f=(t)=>A.find(h=>has(h,t));
  const flyer=f("flyer"), pocket=f("pocketHealer"); if(flyer&&pocket&&flyer!==pocket) add(5,"Pocketed air threat",`${pocket.name} boosts ${flyer.name} into a hard-to-punish flyer.`);
  const air=f("airSupport"); if(flyer&&air&&flyer!==air) add(2,"Air support",`${air.name} sustains ${flyer.name} at altitude.`);
  const su=f("setup"), pay=f("comboUlt"); if(su&&pay&&su!==pay) add(3,"Ult-combo line",`${su.name}'s setup chains into ${pay.name}'s payoff ult.`);
  const amp=f("damageAmp"), carry=f("burstDPS"); if(amp&&carry&&amp!==carry) add(3,"Amplified carry",`${amp.name} turns ${carry.name} into a one-shot threat.`);
  const spd=f("speedEnable"), tk=A.find(h=>h.role==="Tank"&&(h.styles.includes("Dive")||h.styles.includes("Brawl"))); if(spd&&tk&&spd!==tk) add(3,"Speed engage",`${spd.name}'s speed powers ${tk.name}'s commit.`);
  const hk=f("hackSetup"), dv=A.find(h=>has(h,"diveTank")||(h.role==="DPS"&&h.styles.includes("Dive"))); if(hk&&dv&&hk!==dv) add(2,"Hack-assisted dive",`${hk.name} sets up ${dv.name}'s dive.`);
  const dtank=A.find(h=>has(h,"diveTank")), peel=A.find(h=>h.role==="Support"&&has(h,"peelSupport")); if(dtank&&peel&&dtank!==peel) add(2,"Backline peel",`${peel.name} can peel while ${dtank.name} dives.`);
  if(a.role==="Support"&&b.role==="Support"&&has(a,"burstHeal")&&has(b,"burstHeal")) add(2,"Heal core",`${a.name} + ${b.name} stack strong burst healing.`);
  const sn=f("sniper"), bt=f("brawlTankPure"); if(sn&&bt) add(-3,"Sniper / brawl clash",`${sn.name} wants range; ${bt.name} forces close fights.`);
  const an=f("anchorDPS"), d2=f("diveTank"); if(an&&d2) add(-3,"Anchor / dive clash",`${an.name} can't keep pace with ${d2.name}.`);
  const f2=f("flyer"), b2=f("brawlTankPure"); if(f2&&b2) add(-2,"Air / brawl mismatch",`${f2.name} gains little from ${b2.name}.`);
  if(a.role==="Support"&&b.role==="Support"&&has(a,"lowPressure")&&has(b,"lowPressure")) add(-5,"Passive pairing",`${a.name} + ${b.name}: little pressure or peel.`);
  if(a.role==="DPS"&&b.role==="DPS"&&has(a,"sniper")&&has(b,"sniper")) add(-2,"Double sniper",`${a.name} + ${b.name}: thin frontline.`);
  return { pts: out.reduce((s,e)=>s+e.pts,0), reasons: out };
}

/* ── combo chains (sequenced ult/engage interactions) ── */
function detectCombos(sel){
  const names=new Set(sel.map(h=>h.name)); const get=(n)=>HEROES[n];
  const chains=[]; const seen=new Set();
  const rate=(s1,s2)=>Math.max(1,Math.min(10,Math.round((get(s1).scores.ult + get(s2).scores.ult + get(s2).scores.burst)/3)));
  const pushC=(family,note,steps)=>{ const key=family+"|"+steps.map(s=>s.name).join(">"); if(seen.has(key))return; seen.add(key);
    chains.push({ family, note, steps, rating: rate(steps[0].name, steps[steps.length-1].name) }); };
  // anchor → AoE payoff
  for(const [aN,aUlt] of ANCHORS){ if(!names.has(aN)) continue;
    for(const h of sel){ if(h.name===aN) continue; if(has(h,"comboUlt"))
      pushC(`${aN==="Sombra"?"EMP":aN} Combo`, ANCHOR_NOTE[aN], [{name:aN,action:aUlt},{name:h.name,action:ultName(h.name)}]); } }
  // Nano-boost a diving carry
  if(names.has("Ana")) for(const h of sel) if(NANO_TARGETS.has(h.name))
    pushC("Nano Combo","Nano-boost a frontline carry to brute-force the fight.",[{name:"Ana",action:"Nano Boost"},{name:h.name,action:ultName(h.name)==="Ultimate"?"dive in":ultName(h.name)}]);
  // Mercy pocket → carry ult
  if(names.has("Mercy")) for(const h of sel) if(MERCY_TARGETS.has(h.name))
    pushC("Mercy Pocket","Mercy amps the carry's damage for a one-sided ult.",[{name:"Mercy",action:"Damage Boost"},{name:h.name,action:ultName(h.name)}]);
  // Lúcio speed → engage
  if(names.has("Lúcio")) for(const h of sel) if(SPEED_TARGETS.has(h.name)&&h.name!=="Lúcio")
    pushC("Speed Engage","Lúcio speeds the team into an unavoidable engage.",[{name:"Lúcio",action:"Speed Boost"},{name:h.name,action:"engage"}]);
  // Discord → focus a burst carry
  if(names.has("Zenyatta")) for(const h of sel) if(has(h,"burstDPS")&&h.name!=="Zenyatta")
    pushC("Discord Pick","Discord a target so your carry deletes it.",[{name:"Zenyatta",action:"Discord Orb"},{name:h.name,action:"focus fire"}]);
  return chains.sort((a,b)=>b.rating-a.rating).slice(0,6);
}

/* ── sub-role mix dynamics ── */
function subroleDynamics(sel){
  const subs=sel.map(h=>SUBROLE_OF[h.name]).filter(Boolean);
  const cnt={}; subs.forEach(s=>cnt[s]=(cnt[s]||0)+1);
  const tank=sel.find(h=>h.role==="Tank"); const dps=sel.filter(h=>h.role==="DPS"); const sup=sel.filter(h=>h.role==="Support");
  const tankSub=tank?SUBROLE_OF[tank.name]:null;
  const supSubs=sup.map(h=>SUBROLE_OF[h.name]);
  const notes=[]; const add=(kind,text)=>notes.push({kind,text});
  if((cnt.Tactician||0)>=2) add("pos","Stacked ult economy — two Tacticians bank excess charge for relentless back-to-back ultimates.");
  if((cnt.Medic||0)>=2) add("neg","Heal-stacked — strong raw healing but thin on utility and pick pressure; can get out-tempo'd.");
  if(sup.length>=2 && (cnt.Medic||0)===0) add("note","No Medic — sustain rides on Survivor/Tactician throughput; mind long fights.");
  if((cnt.Sharpshooter||0)>=2) add("note","Long-range core — heavy poke pressure, but exposed to dive and close range.");
  if((cnt.Specialist||0)>=2) add("pos","Zoning core — multiple Specialists lock down chokes and deny space.");
  const flankers=dps.filter(h=>SUBROLE_OF[h.name]==="Flanker");
  if(flankers.length && !supSubs.includes("Survivor")) add("neg",`${flankers.map(h=>h.name).join(", ")} dive with no Survivor support to peel or escape — high risk.`);
  if(tankSub==="Initiator" && flankers.length) add("pos",`Dive package — ${tank.name} (Initiator) and your Flanker${flankers.length>1?"s":""} hit the backline together.`);
  if(tankSub==="Stalwart" && dps.some(h=>["Sharpshooter","Recon"].includes(SUBROLE_OF[h.name]))) add("pos",`Poke package — ${tank.name} (Stalwart) screens for your ranged DPS.`);
  if(tankSub==="Bruiser") add("pos",`Brawl package — ${tank.name} (Bruiser) front-lines a close-range fight where its sustain shines.`);
  if(notes.length===0) add("note","Balanced sub-role spread — no single passive dominates, no glaring gap.");
  return { cnt, notes };
}

/* ════════════════════════ STRATEGY ════════════════════════ */
const STRATEGY = {
  Dive: { tag:"Burst onto one target, then reset.", plan:[
    "Commit together — land the tank, a diver, and a support cooldown on one squishy at the same moment.",
    "Take off-angles and high ground before engaging; never walk in from the front.",
    "Hunt the enemy supports and snipers first — kill the backline and the fight collapses.",
    "Dive, secure the pick, disengage with your mobility, repeat. Don't overstay the engage." ],
    set:["Hard-countered by anti-dive (Brig, Mei, Zarya, Ana, Cassidy) and grouped brawl that punishes the commit.",
    "Falls apart without coordination — a solo dive just feeds. Demands timing and comms.",
    "Squishy divers die instantly if the engage is mistimed or focus is split."] },
  Brawl: { tag:"Group up, control space, win the sustained fight.", plan:[
    "Fight as a tight unit in close quarters — funnel into chokes and rooms around your tank.",
    "Use speed (Lúcio) to force the engage on your terms, then layer area ults (Blizzard, Death Blossom, Grav) on the grouped enemy.",
    "Zone with walls and barriers (Mei, Sigma) and walk them down where they can't kite.",
    "Out-heal and out-trade them in prolonged fights — sustain is your win condition."],
    set:["Out-ranged by poke — snipers chip you before you close. Avoid open sightlines.",
    "Anti-heal (Ana nade) and hard burst gut the sustain core.",
    "Slow to rotate and easily kited on open maps; you need cover to advance."] },
  Poke: { tag:"Hold range, win the ult economy, then commit.", plan:[
    "Hold long sightlines and high ground — deal damage from where they can't reach.",
    "Use barriers and cover to chip them and build an ult advantage before committing.",
    "Force the enemy to engage into your zoning; coordinate sniper picks with shield breaks.",
    "Convert a pick into space — only push the objective once a fight is already won."],
    set:["Hard-countered by dive — mobile heroes close the gap and delete your immobile backline.",
    "Weak in close quarters and on flank-heavy maps; struggles once forced off sightlines.",
    "Passive by nature — can bleed objective time if it never commits to a fight."] },
};
const FALLBACK = { tag:"Pick a clear identity.", plan:[
  "Commit to one win condition — decide each fight whether you're diving, brawling, or holding range.",
  "Flex comps work, but only with a defined plan; otherwise coordination breaks down."],
  set:["A jack-of-all-trades risks losing every range band.","Without an identity the synergy and matchup math both suffer."] };

/* ════════════════════════ HELPERS ════════════════════════ */
function lerp(a,b,t){return a+(b-a)*t;}
function heat(v){ const lo=[239,68,68],mid=[245,158,11],hi=[52,211,153]; let c;
  if(v<=5.5){const t=(v-1)/4.5;c=lo.map((x,i)=>lerp(x,mid[i],t));} else {const t=(v-5.5)/4.5;c=mid.map((x,i)=>lerp(x,hi[i],t));}
  return c.map(x=>Math.round(x)); }
const FONT_D="'Chakra Petch', sans-serif", FONT_M="'JetBrains Mono', monospace";
const rgb=(a)=>`rgb(${a.join(",")})`, rgba=(a,o)=>`rgba(${a.join(",")},${o})`;

/* ════════════════════════ MATRIX VIEW ════════════════════════ */
const ALL_HEROES = Object.values(HEROES);
const PROVISIONAL = new Set(["Mizuki","Vendetta","Sierra","Emre","Anran","Freja","Domina","Jetpack Cat","Wuyang"]);
const MATRIX_FACTORS = [
  {key:"hp",label:"Health Pool",desc:"Relative effective health (approx.)"},
  {key:"speed",label:"Speed",desc:"Base movement + repositioning frequency"},
  {key:"vert",label:"Vertical Mobility",desc:"Access to high ground / flight"},
  {key:"ult",label:"Ult Potential",desc:"Game-swinging power of ultimate"},
  {key:"space",label:"Spacing Control",desc:"Area denial, zoning, displacement"},
  {key:"dura",label:"Durability",desc:"Effective survivability incl. mitigation & sustain"},
  {key:"burst",label:"Burst Damage",desc:"Damage in a short window / one-shot potential"},
  {key:"range",label:"Range",desc:"Effective engagement range"},
  {key:"skill",label:"Skill Ceiling",desc:"Mechanical + decision demand (high = harder)"},
];
const WPRESETS = {
  Balanced: Object.fromEntries(FK.map(k=>[k,1])),
  "Aggro / Carry": {hp:0.5,speed:1.4,vert:1,ult:1.3,space:0.7,dura:0.7,burst:2,range:1.2,skill:1.3},
  "Sustain / Anchor": {hp:1.8,speed:0.6,vert:0.5,ult:1.1,space:1.5,dura:2,burst:0.8,range:0.9,skill:0.6},
  "Poke / Pick": {hp:0.6,speed:0.9,vert:1.3,ult:0.9,space:1,dura:0.7,burst:1.6,range:2,skill:1.4},
};
function mThStyle({align="center",w,sticky=false,left,z=5,active=false}={}){
  return { position:"sticky", top:0, ...(sticky?{left,zIndex:z}:{zIndex:4}),
    background:"#10131a", color:active?"#eef1f6":"#7c8595", fontFamily:FONT_D, fontSize:10.5, fontWeight:600, letterSpacing:1.2,
    padding:"11px 6px", textAlign:align, whiteSpace:"nowrap", cursor:"pointer", userSelect:"none",
    borderBottom:"1px solid #1f232c", ...(sticky?{borderRight:"1px solid #1f232c",minWidth:w}:{}),
    ...(w&&!sticky?{minWidth:w}:{}), boxShadow:active?"inset 0 -2px 0 #34d399":"none" };
}
function GraphSVG({sel}){
  const n=sel.length, cx=170, cy=135, R=n===1?0:98;
  const nodes=sel.map((h,i)=>{ const ang=-Math.PI/2 + i*2*Math.PI/n; return {h, x:cx+R*Math.cos(ang), y:cy+R*Math.sin(ang)}; });
  const viz=nodes.map(nd=>({nd, ...sigilShapes(nd.h.name, ROLE_C[nd.h.role])}));
  const edges=[];
  for(let i=0;i<nodes.length;i++) for(let j=i+1;j<nodes.length;j++){ const ps=pairSynergy(nodes[i].h,nodes[j].h); if(ps.pts!==0) edges.push({a:nodes[i],b:nodes[j],pts:ps.pts}); }
  return (
    <svg viewBox="0 0 340 290" style={{width:"100%",maxWidth:380,display:"block",margin:"0 auto"}}>
      <defs>{viz.map(v=><filter key={v.fid} id={v.fid} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3.2"/></filter>)}</defs>
      {edges.map((e,i)=>{ const c=e.pts>0?[52,211,153]:[248,113,113]; const w=1.2+Math.min(Math.abs(e.pts),6)*0.45; const o=0.4+Math.min(Math.abs(e.pts),6)*0.08;
        return <line key={i} x1={e.a.x} y1={e.a.y} x2={e.b.x} y2={e.b.y} stroke={`rgba(${c[0]},${c[1]},${c[2]},${o})`} strokeWidth={w} strokeLinecap="round"/>; })}
      {viz.map((v,i)=>(
        <g key={i}>
          <circle cx={v.nd.x} cy={v.nd.y} r={25} fill="#0b0d12" stroke={rgba(ROLE_C[v.nd.h.role],0.5)} strokeWidth={1}/>
          <g transform={`translate(${v.nd.x-25} ${v.nd.y-25}) scale(0.5)`}>{v.shapes.map((s,k)=>React.createElement(s.type,{key:k,...s.attr}))}</g>
          <text x={v.nd.x} y={v.nd.y+39} textAnchor="middle" fontFamily={FONT_M} fontSize="9" fontWeight="600" fill={rgb(ROLE_C[v.nd.h.role])}>{v.nd.h.name}</text>
        </g>
      ))}
    </svg>
  );
}

function DynamicsView({youNames,enemyNames}){
  const [side,setSide]=useState("you");
  const names=(side==="you"?youNames:enemyNames);
  const accent=side==="you"?[52,211,153]:[248,113,113];
  const sel=names.filter(Boolean).map(n=>HEROES[n]);
  const pairList=[];
  for(let i=0;i<sel.length;i++) for(let j=i+1;j<sel.length;j++){ const ps=pairSynergy(sel[i],sel[j]); if(ps.pts!==0) pairList.push({a:sel[i].name,b:sel[j].name,pts:ps.pts,reasons:ps.reasons}); }
  pairList.sort((a,b)=>Math.abs(b.pts)-Math.abs(a.pts));
  const combos=detectCombos(sel);
  const sub=subroleDynamics(sel);
  const synSum=pairList.reduce((s,e)=>s+e.pts,0);

  return (
    <div style={{display:"flex",flexDirection:"column",gap:18}}>
      <div style={{display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}>
        <span style={{fontSize:10.5,letterSpacing:2,color:"#6b7280",marginRight:2}}>DYNAMICS FOR</span>
        {[["you","YOUR TEAM",[52,211,153]],["enemy","ENEMY TEAM",[248,113,113]]].map(([v,l,c])=>{ const a=side===v;
          return <button key={v} onClick={()=>setSide(v)} style={{border:`1px solid ${a?rgba(c,0.5):"#1b1e26"}`,cursor:"pointer",padding:"7px 13px",borderRadius:8,fontFamily:FONT_D,fontSize:12.5,fontWeight:600,letterSpacing:0.6,background:a?rgba(c,0.12):"transparent",color:a?rgb(c):"#727b8a"}}>{l}</button>;})}
      </div>

      {sel.length<2 ? (
        <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:24,textAlign:"center",color:"#7c8595"}}>
          Add at least 2 heroes in <b style={{color:"#cdd3dd"}}>Build</b> to map this team's dynamics.
        </div>
      ) : (
        <>
          {/* relationship graph */}
          <div style={{background:"#0b0d12",border:`1px solid ${rgba(accent,0.28)}`,borderRadius:16,padding:"15px 16px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:6,marginBottom:8}}>
              <span style={{fontSize:11,letterSpacing:2,color:"#6b7280",fontWeight:700}}>RELATIONSHIP WEB</span>
              <span style={{fontFamily:FONT_M,fontSize:11,color:synSum>=0?"#34d399":"#f87171"}}>net links {synSum>=0?"+":""}{synSum}</span>
            </div>
            <GraphSVG sel={sel}/>
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:16,fontFamily:FONT_M,fontSize:10.5,color:"#727b8a",marginTop:4}}>
              <span style={{display:"flex",alignItems:"center",gap:6}}><span style={{width:16,height:3,borderRadius:2,background:"rgb(52,211,153)"}}/>synergy</span>
              <span style={{display:"flex",alignItems:"center",gap:6}}><span style={{width:16,height:3,borderRadius:2,background:"rgb(248,113,113)"}}/>friction</span>
              <span>thickness = strength</span>
            </div>
            {pairList.length>0 && (
              <div style={{marginTop:14,display:"flex",flexDirection:"column",gap:9,borderTop:"1px solid #14171e",paddingTop:13}}>
                {pairList.map((e,i)=>{ const c=e.pts>0?[52,211,153]:[248,113,113];
                  return <div key={i} style={{display:"flex",gap:10}}>
                    <span style={{flexShrink:0,fontFamily:FONT_M,fontSize:12,fontWeight:700,width:28,textAlign:"right",color:rgb(c)}}>{e.pts>0?"+":""}{e.pts}</span>
                    <div style={{borderLeft:`2px solid ${rgba(c,0.5)}`,paddingLeft:10}}>
                      <div style={{fontSize:12.5,fontWeight:600,color:"#e7eaf0"}}>{e.a} <span style={{color:"#5b6270"}}>⟷</span> {e.b}</div>
                      <div style={{fontSize:11,color:"#828b9b",lineHeight:1.45}}>{e.reasons.map(r=>r.reason).join(" ")}</div>
                    </div></div>; })}
              </div>
            )}
          </div>

          {/* combo chains */}
          <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:16,padding:"15px 17px"}}>
            <div style={{fontSize:11,letterSpacing:2,color:"#6b7280",fontWeight:700,marginBottom:13}}>COMBO CHAINS — {combos.length} sequenced {combos.length===1?"play":"plays"}</div>
            {combos.length===0 && <div style={{color:"#828b9b",fontSize:12.5,lineHeight:1.5}}>No multi-hero ult combos with this lineup — this comp wins through individual pressure and tempo rather than set-piece combos.</div>}
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              {combos.map((ch,i)=>(
                <div key={i}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:7}}>
                    <span style={{fontFamily:FONT_M,fontSize:10.5,fontWeight:700,color:"#06210f",background:rgb(accent),borderRadius:6,padding:"2px 7px"}}>{ch.rating}/10</span>
                    <span style={{fontSize:13.5,fontWeight:700,color:"#eef1f6"}}>{ch.family}</span>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                    {ch.steps.map((st,k)=>(
                      <React.Fragment key={k}>
                        {k>0 && <span style={{color:rgb(accent),fontSize:16,fontWeight:700}}>→</span>}
                        <div style={{display:"flex",alignItems:"center",gap:7,background:"#0e1117",border:"1px solid #1b1e26",borderRadius:10,padding:"6px 10px 6px 6px"}}>
                          <Sigil name={st.name} rgb={ROLE_C[HEROES[st.name].role]} size={26}/>
                          <div style={{lineHeight:1.15}}>
                            <div style={{fontSize:12.5,fontWeight:700,color:"#e7eaf0"}}>{st.name}</div>
                            <div style={{fontSize:10,color:"#828b9b",fontFamily:FONT_M}}>{st.action}</div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                  <div style={{fontSize:11,color:"#727b8a",marginTop:6,lineHeight:1.45}}>{ch.note}</div>
                </div>
              ))}
            </div>
          </div>

          {/* sub-role dynamics */}
          <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:16,padding:"15px 17px"}}>
            <div style={{fontSize:11,letterSpacing:2,color:"#6b7280",fontWeight:700,marginBottom:12}}>SUB-ROLE DYNAMICS</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:13}}>
              {Object.entries(sub.cnt).map(([s,n])=>{ const role=SUBROLES[s].role; const c=ROLE_C[role];
                return <span key={s} style={{fontSize:11.5,fontWeight:600,padding:"3px 9px",borderRadius:7,color:rgb(c),background:rgba(c,0.12),border:`1px solid ${rgba(c,0.3)}`}}>{s}{n>1?` ×${n}`:""}</span>;})}
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:9}}>
              {sub.notes.map((nt,i)=>{ const c=nt.kind==="pos"?[52,211,153]:nt.kind==="neg"?[248,113,113]:[148,156,168];
                return <div key={i} style={{display:"flex",gap:9}}>
                  <span style={{flexShrink:0,color:rgb(c),fontWeight:700,fontFamily:FONT_M,fontSize:13,width:14}}>{nt.kind==="pos"?"+":nt.kind==="neg"?"–":"◦"}</span>
                  <span style={{fontSize:12.5,color:"#cdd3dd",lineHeight:1.5}}>{nt.text}</span></div>;})}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function ClassesView(){
  const [openHero,setOpenHero]=useState(null);
  const ARCH_C={Dive:[96,165,250],Brawl:[245,158,11],Poke:[52,211,153]};
  const archColor=(h)=> ARCH_C[h.styles[0]]||[148,156,168];
  return (
    <div>
      <div style={{fontSize:13,letterSpacing:2,fontWeight:700,color:"#34d399",marginBottom:6}}>HERO CLASSIFICATION <span style={{color:"#5b6270",fontWeight:500,letterSpacing:0}}>· official 2026 sub-roles + comp archetype</span></div>
      <p style={{margin:"0 0 18px",fontSize:12.5,lineHeight:1.6,color:"#8a93a3",maxWidth:760}}>
        Every hero carries two tags: its <b style={{color:"#cdd3dd"}}>sub-role</b> (Blizzard's Reign of Talon passive class — the small group it shares a passive with) and its <b style={{color:"#cdd3dd"}}>archetype</b> (the Dive / Brawl / Poke identity this app uses for synergy and matchups; hybrids show both, e.g. <span style={{color:"#cdd3dd"}}>Poke-Dive</span>). Tap a hero for the full breakdown.
      </p>

      {["Tank","DPS","Support"].map(role=>{
        const rc=ROLE_C[role];
        const subs=SUBROLE_ORDER.filter(s=>SUBROLES[s].role===role);
        return (
          <div key={role} style={{marginBottom:22}}>
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:11}}>
              <span style={{width:4,height:16,borderRadius:2,background:rgb(rc),boxShadow:`0 0 8px ${rgba(rc,0.6)}`}}/>
              <span style={{fontSize:14,fontWeight:700,letterSpacing:1.5,color:rgb(rc)}}>{role.toUpperCase()}</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(270px,1fr))",gap:12}}>
              {subs.map(sub=>{ const meta=SUBROLES[sub];
                return (
                  <div key={sub} style={{background:"#0b0d12",border:`1px solid ${rgba(rc,0.28)}`,borderRadius:13,padding:"13px 14px"}}>
                    <div style={{display:"flex",alignItems:"baseline",justifyContent:"space-between",gap:8}}>
                      <span style={{fontSize:15,fontWeight:700,color:"#eef1f6",letterSpacing:0.3}}>{sub}</span>
                      <span style={{fontFamily:FONT_M,fontSize:10.5,color:rgb(rc)}}>{meta.heroes.filter(h=>HEROES[h]).length}</span>
                    </div>
                    <div style={{fontSize:11,color:rgba(rc,0.95),fontWeight:600,marginTop:3,lineHeight:1.4}}>{meta.passive}</div>
                    <div style={{fontSize:11.5,color:"#828b9b",marginTop:5,lineHeight:1.45}}>{meta.blurb}</div>
                    <div style={{display:"flex",flexWrap:"wrap",gap:6,marginTop:11}}>
                      {meta.heroes.filter(h=>HEROES[h]).map(h=>{ const hero=HEROES[h]; const ac=archColor(hero); const open=openHero===h;
                        return (
                          <button key={h} onClick={()=>setOpenHero(open?null:h)} style={{display:"inline-flex",alignItems:"center",gap:6,cursor:"pointer",
                            background:open?rgba(ac,0.16):"#0e1117",border:`1px solid ${open?rgba(ac,0.55):"#1b1e26"}`,borderRadius:8,padding:"4px 8px 4px 4px"}}>
                            <Sigil name={h} rgb={ROLE_C[hero.role]} size={20}/>
                            <span style={{fontSize:12,fontWeight:600,color:"#e7eaf0"}}>{h}{PROVISIONAL.has(h)&&<span style={{color:"#f59e0b",fontSize:10,marginLeft:3}}>＊</span>}</span>
                          </button>
                        );})}
                    </div>
                  </div>
                );})}
            </div>
          </div>
        );
      })}

      {openHero && (()=>{ const h=HEROES[openHero]; const rc=ROLE_C[h.role]; const ac=ARCH_C[h.styles[0]]||[148,156,168]; const sub=SUBROLE_OF[openHero];
        return (
          <div onClick={()=>setOpenHero(null)} style={{position:"fixed",inset:0,zIndex:50,background:"rgba(3,4,6,0.74)",backdropFilter:"blur(3px)",display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
            <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:420,background:"#0c0e13",border:`1px solid ${rgba(rc,0.4)}`,borderRadius:16,padding:18,boxShadow:`0 20px 60px rgba(0,0,0,.6), inset 0 0 34px ${rgba(rc,0.06)}`}}>
              <div style={{display:"flex",alignItems:"center",gap:13}}>
                <Sigil name={openHero} rgb={rc} size={56}/>
                <div style={{flex:1}}>
                  <div style={{fontSize:20,fontWeight:700,color:"#eef1f6",lineHeight:1.05}}>{openHero}{PROVISIONAL.has(openHero)&&<span style={{color:"#f59e0b",fontSize:13,marginLeft:5}}>＊</span>}</div>
                  <div style={{display:"flex",gap:6,marginTop:6,flexWrap:"wrap"}}>
                    <span style={{fontSize:10.5,fontWeight:700,letterSpacing:0.5,padding:"2px 8px",borderRadius:6,color:rgb(rc),background:rgba(rc,0.13),border:`1px solid ${rgba(rc,0.4)}`}}>{h.role.toUpperCase()}</span>
                    <span style={{fontSize:10.5,fontWeight:700,letterSpacing:0.5,padding:"2px 8px",borderRadius:6,color:"#e7eaf0",background:"#171a21",border:"1px solid #2a2e38"}}>{sub}</span>
                    <span style={{fontSize:10.5,fontWeight:700,letterSpacing:0.5,padding:"2px 8px",borderRadius:6,color:rgb(ac),background:rgba(ac,0.13),border:`1px solid ${rgba(ac,0.4)}`}}>{archetypeOf(h)}</span>
                  </div>
                </div>
                <button onClick={()=>setOpenHero(null)} style={{...ghostBtn,padding:"5px 10px"}}>✕</button>
              </div>
              <div style={{marginTop:14,fontSize:11,letterSpacing:1.5,color:"#6b7280",fontWeight:700}}>SUB-ROLE PASSIVE</div>
              <div style={{fontSize:12.5,color:"#cdd3dd",marginTop:4,lineHeight:1.5}}>{SUBROLES[sub].passive}</div>
              <div style={{marginTop:13,fontSize:11,letterSpacing:1.5,color:"#6b7280",fontWeight:700}}>AXIS PROFILE</div>
              <div style={{marginTop:7}}>
                {FK.map(k=>{ const v=h.scores[k]; const[r,g,b]=heat(v);
                  return <div key={k} style={{display:"flex",alignItems:"center",gap:9,marginBottom:5}}>
                    <span style={{width:40,fontFamily:FONT_M,fontSize:10,color:"#7c8595"}}>{FLABEL[k]}</span>
                    <span style={{flex:1,height:6,borderRadius:9,background:"#15181f",overflow:"hidden"}}><span style={{display:"block",width:`${v*10}%`,height:"100%",borderRadius:9,background:`rgb(${r},${g},${b})`}}/></span>
                    <span style={{width:18,textAlign:"right",fontFamily:FONT_M,fontSize:11,color:`rgb(${r},${g},${b})`}}>{v}</span>
                  </div>;})}
              </div>
            </div>
          </div>
        );})()}
    </div>
  );
}

function MatrixView(){
  const [role,setRole]=useState("All");
  const [weights,setWeights]=useState(WPRESETS.Balanced);
  const [activePreset,setActivePreset]=useState("Balanced");
  const [sortKey,setSortKey]=useState("composite");
  const [sortDir,setSortDir]=useState("desc");
  const [showInfo,setShowInfo]=useState(false);

  const wSum=Object.values(weights).reduce((a,b)=>a+b,0)||1;
  const cmp=(h)=>MATRIX_FACTORS.reduce((acc,f)=>acc+h.scores[f.key]*weights[f.key],0)/wSum;
  const filtered=useMemo(()=>ALL_HEROES.filter(h=>role==="All"||h.role===role),[role]);
  const rankMap=useMemo(()=>{const m=new Map();[...filtered].sort((a,b)=>cmp(b)-cmp(a)).forEach((h,i)=>m.set(h.name,i+1));return m;},[filtered,weights]);
  const sorted=useMemo(()=>{const arr=[...filtered];arr.sort((a,b)=>{
    if(sortKey==="name") return sortDir==="asc"?a.name.localeCompare(b.name):b.name.localeCompare(a.name);
    let av,bv; if(sortKey==="composite"){av=cmp(a);bv=cmp(b);} else {av=a.scores[sortKey];bv=b.scores[sortKey];}
    return sortDir==="asc"?av-bv:bv-av;}); return arr;},[filtered,sortKey,sortDir,weights]);

  const clickSort=(k)=>{ if(sortKey===k) setSortDir(d=>d==="asc"?"desc":"asc"); else {setSortKey(k);setSortDir(k==="name"?"asc":"desc");} };
  const arrow=(k)=> sortKey===k?(sortDir==="asc"?" ▲":" ▼"):"";
  const setW=(k,v)=>{setWeights(w=>({...w,[k]:v}));setActivePreset("Custom");};

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:10,marginBottom:12}}>
        <div style={{fontSize:13,letterSpacing:2,fontWeight:700,color:"#34d399"}}>HERO MATRIX <span style={{color:"#5b6270",fontWeight:500,letterSpacing:0}}>· {sorted.length} heroes, nine axes</span></div>
        <button onClick={()=>setShowInfo(v=>!v)} style={ghostBtn}>{showInfo?"HIDE ✕":"HOW SCORING WORKS ⓘ"}</button>
      </div>

      {showInfo && (
        <div style={{background:"#0d0f14",border:"1px solid #1b1e26",borderRadius:12,padding:16,marginBottom:16,fontSize:12.5,lineHeight:1.7,color:"#aab2c0"}}>
          <p style={{marginTop:0}}>Every hero is scored <b style={{color:"#e7eaf0"}}>1–10 on nine axes</b>. The <b style={{color:"#e7eaf0"}}>composite</b> is a weighted average — drag the sliders or pick a preset and the ranking re-sorts live. Tap any column header to sort by it.</p>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:"2px 18px",marginBottom:10}}>
            {MATRIX_FACTORS.map(f=><div key={f.key}><b style={{color:"#cdd3dd"}}>{FLABEL[f.key]}</b> — {f.desc}</div>)}
          </div>
          <p style={{margin:0,color:"#7c8595"}}><b style={{color:"#f59e0b"}}>Caveats:</b> the judgment axes are a defensible kit-based read, not objective fact. <b style={{color:"#cdd3dd"}}>HP</b> is a relative pool score, not exact health. Heroes marked <b style={{color:"#f59e0b"}}>＊</b> (the 2026 additions + Mizuki) are educated estimates — their kits are researched but newer, so scores are less settled. Hazard and the unreleased Season 3–6 heroes aren't in yet.</p>
        </div>
      )}

      <div style={{display:"flex",flexWrap:"wrap",gap:10,alignItems:"center",marginBottom:14}}>
        <div style={{display:"flex",gap:4,background:"#0d0f14",border:"1px solid #1b1e26",borderRadius:10,padding:4}}>
          {["All","Tank","DPS","Support"].map(rr=>{ const active=role===rr; const rc=rr==="All"?[231,234,240]:ROLE_C[rr];
            return <button key={rr} onClick={()=>setRole(rr)} style={{border:"none",cursor:"pointer",padding:"7px 13px",borderRadius:7,fontFamily:FONT_D,fontSize:13,fontWeight:600,letterSpacing:1,
              background:active?rgba(rc,0.14):"transparent",color:active?rgb(rc):"#727b8a",boxShadow:active?`inset 0 0 0 1px ${rgba(rc,0.5)}`:"none"}}>{rr.toUpperCase()}</button>;})}
        </div>
        <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
          {Object.keys(WPRESETS).map(p=>{ const active=activePreset===p;
            return <button key={p} onClick={()=>{setWeights(WPRESETS[p]);setActivePreset(p);}} style={{border:`1px solid ${active?"#3a3f4b":"#1b1e26"}`,cursor:"pointer",padding:"7px 11px",borderRadius:8,fontFamily:FONT_M,fontSize:11.5,
              background:active?"#171a21":"transparent",color:active?"#e7eaf0":"#727b8a",letterSpacing:0.3}}>{p}</button>;})}
          {activePreset==="Custom" && <span style={{alignSelf:"center",fontFamily:FONT_M,fontSize:11,color:"#f59e0b",letterSpacing:1}}>● CUSTOM</span>}
        </div>
      </div>

      <div style={{background:"#0d0f14",border:"1px solid #1b1e26",borderRadius:12,padding:"14px 16px",marginBottom:16}}>
        <div style={{fontSize:10.5,letterSpacing:3,color:"#6b7280",fontWeight:600,marginBottom:12}}>FACTOR WEIGHTS</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:"14px 22px"}}>
          {MATRIX_FACTORS.map(f=>(
            <div key={f.key} title={f.desc}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12,color:"#cdd3dd",fontWeight:500}}>{f.label}</span>
                <span style={{fontFamily:FONT_M,fontSize:12,color:weights[f.key]===0?"#52596680":"#e7eaf0"}}>{weights[f.key].toFixed(2)}×</span>
              </div>
              <input type="range" min="0" max="3" step="0.25" value={weights[f.key]} onChange={e=>setW(f.key,parseFloat(e.target.value))} style={{width:"100%"}}/>
            </div>
          ))}
        </div>
      </div>

      <div style={{border:"1px solid #1b1e26",borderRadius:12,overflow:"hidden",background:"#0a0c10"}}>
        <div style={{overflowX:"auto",overflowY:"auto",maxHeight:"68vh"}}>
          <table style={{borderCollapse:"separate",borderSpacing:0,width:"100%",minWidth:780}}>
            <thead>
              <tr>
                <th onClick={()=>clickSort("composite")} style={mThStyle({left:0,z:6,sticky:true,align:"left",w:196,active:sortKey==="composite"})}>HERO{arrow("composite")}</th>
                {MATRIX_FACTORS.map(f=>(<th key={f.key} title={f.label} onClick={()=>clickSort(f.key)} style={mThStyle({active:sortKey===f.key})}>{FLABEL[f.key]}{arrow(f.key)}</th>))}
                <th onClick={()=>clickSort("composite")} style={mThStyle({active:sortKey==="composite",w:132})}>SCORE{arrow("composite")}</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((h,idx)=>{ const rc=ROLE_C[h.role]; const c=cmp(h); const rank=rankMap.get(h.name); const bg=idx%2?"#0c0e13":"#0a0c10";
                return (
                  <tr key={h.name} style={{background:bg}}>
                    <td style={{position:"sticky",left:0,zIndex:3,background:bg,padding:"8px 12px",borderBottom:"1px solid #14171e",borderRight:"1px solid #14171e",minWidth:196}}>
                      <div style={{display:"flex",alignItems:"center",gap:9}}>
                        <span style={{fontFamily:FONT_M,fontSize:11,color:"#5b6270",width:18,textAlign:"right"}}>{rank}</span>
                        <Sigil name={h.name} rgb={rc} size={30}/>
                        <span style={{fontSize:14,fontWeight:600,color:"#eef1f6",lineHeight:1.1}}>
                          {h.name}{PROVISIONAL.has(h.name)&&<span title="Provisional — kit still settling" style={{color:"#f59e0b",fontSize:11,marginLeft:4}}>＊</span>}
                          <span style={{display:"block",fontSize:9.5,letterSpacing:1,color:rgba(rc,0.85),fontWeight:600}}>{SUBROLE_OF[h.name]||h.role} · {archetypeOf(h)}</span>
                        </span>
                      </div>
                    </td>
                    {MATRIX_FACTORS.map(f=>{ const v=h.scores[f.key]; const[r,g,b]=heat(v);
                      return <td key={f.key} style={{textAlign:"center",padding:"8px 4px",borderBottom:"1px solid #14171e",fontFamily:FONT_M,fontSize:13,fontWeight:500,color:`rgb(${r},${g},${b})`,background:`rgba(${r},${g},${b},0.10)`}}>{v}</td>;})}
                    <td style={{padding:"8px 12px",borderBottom:"1px solid #14171e",minWidth:132}}>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                        <div style={{flex:1,height:5,borderRadius:99,background:"#1a1d25",overflow:"hidden"}}>
                          <div style={{width:`${(c/10)*100}%`,height:"100%",borderRadius:99,background:rgb(rc)}}/></div>
                        <span style={{fontFamily:FONT_M,fontSize:14,fontWeight:700,color:"#eef1f6",width:34,textAlign:"right"}}>{c.toFixed(1)}</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:14,marginTop:13,flexWrap:"wrap",fontFamily:FONT_M,fontSize:11,color:"#727b8a"}}>
        <span style={{display:"flex",alignItems:"center",gap:7}}>LOW<span style={{width:130,height:7,borderRadius:99,background:"linear-gradient(90deg, rgb(239,68,68), rgb(245,158,11), rgb(52,211,153))"}}/>HIGH</span>
        <span style={{color:"#f59e0b"}}>＊ provisional</span>
      </div>
    </div>
  );
}

/* ════════════════════════ APP ════════════════════════ */
const blank = () => [{role:"Tank",hero:null},{role:"DPS",hero:null},{role:"DPS",hero:null},{role:"Support",hero:null},{role:"Support",hero:null}];

export default function App(){
  const [you,setYou]=useState(blank());
  const [enemy,setEnemy]=useState(blank());
  const [picker,setPicker]=useState(null); // {team, index}
  const [view,setView]=useState("build");
  const [stratSide,setStratSide]=useState("you");

  const setTeam=(team)=> team==="you"?setYou:setEnemy;
  const slotsOf=(team)=> team==="you"?you:enemy;
  const assign=(team,i,hero)=>{ setTeam(team)(s=>s.map((x,k)=>k===i?{...x,hero}:x)); setPicker(null); };
  const clearSlot=(team,i)=> setTeam(team)(s=>s.map((x,k)=>k===i?{...x,hero:null}:x));
  const loadPreset=(team,key)=> setTeam(team)(blank().map((s,i)=>({...s,hero:PRESETS[key][i]})));
  const clearAll=(team)=> setTeam(team)(blank());

  const youNames=you.map(s=>s.hero), enemyNames=enemy.map(s=>s.hero);
  const youR=useMemo(()=>analyze(youNames),[you]);
  const enemyR=useMemo(()=>analyze(enemyNames),[enemy]);
  const m=useMemo(()=>matchup(youNames,enemyNames),[you,enemy]);

  return (
    <div style={{minHeight:"100vh",background:"#070809",color:"#e7eaf0",fontFamily:FONT_D,position:"relative"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
        *{box-sizing:border-box} ::selection{background:#34d39955}
        .pk::-webkit-scrollbar{width:8px}.pk::-webkit-scrollbar-thumb{background:#23262e;border-radius:9px}
        input[type=range]{-webkit-appearance:none;appearance:none;height:3px;border-radius:99px;background:#23262e;outline:none;cursor:pointer;}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:#e7eaf0;box-shadow:0 0 8px rgba(231,234,240,.5);}
        input[type=range]::-moz-range-thumb{width:13px;height:13px;border:none;border-radius:50%;background:#e7eaf0;box-shadow:0 0 8px rgba(231,234,240,.5);}`}</style>
      <div style={{position:"fixed",inset:0,pointerEvents:"none",opacity:0.4,
        backgroundImage:"linear-gradient(#11141a 1px,transparent 1px),linear-gradient(90deg,#11141a 1px,transparent 1px)",
        backgroundSize:"44px 44px",maskImage:"radial-gradient(ellipse at 50% 0%, #000 30%, transparent 80%)"}}/>

      <div style={{position:"relative",maxWidth:1080,margin:"0 auto",padding:"26px 16px 72px"}}>
        {/* brand */}
        <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
          <div style={{width:34,height:34,borderRadius:9,background:"linear-gradient(135deg,#34d399,#60a5fa)",
            display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,color:"#06210f",boxShadow:"0 0 18px rgba(52,211,153,.4)"}}>◎</div>
          <div>
            <h1 style={{margin:0,fontSize:26,fontWeight:700,letterSpacing:1.5,lineHeight:1}}>OW<span style={{color:"#34d399"}}>Nexus</span></h1>
            <div style={{fontSize:10.5,letterSpacing:2.5,color:"#6b7280",marginTop:2}}>TEAM HUB · STRATEGY STUDY</div>
          </div>
          <div style={{marginLeft:"auto",display:"flex",flexWrap:"wrap",gap:4,background:"#0d0f14",border:"1px solid #1b1e26",borderRadius:11,padding:4}}>
            {[["build","BUILD"],["matrix","MATRIX"],["classes","CLASSES"],["dynamics","DYNAMICS"],["matchup","MATCHUP"],["strategy","STRATEGY"]].map(([v,l])=>{
              const a=view===v;
              return <button key={v} onClick={()=>setView(v)} style={{border:"none",cursor:"pointer",padding:"8px 14px",borderRadius:8,
                fontFamily:FONT_D,fontSize:12.5,fontWeight:600,letterSpacing:1,
                background:a?"rgba(52,211,153,0.13)":"transparent",color:a?"#34d399":"#727b8a",
                boxShadow:a?"inset 0 0 0 1px rgba(52,211,153,0.45)":"none"}}>{l}</button>;
            })}
          </div>
        </div>

        <div style={{height:22}}/>

        {view==="build" && (
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(330px,1fr))",gap:16}}>
            <TeamPanel side="you" title="YOUR TEAM" accent={[52,211,153]} slots={you} r={youR}
              onOpen={(i)=>setPicker({team:"you",index:i})} onClear={(i)=>clearSlot("you",i)}
              onPreset={(k)=>loadPreset("you",k)} onClear2={()=>clearAll("you")} />
            <TeamPanel side="enemy" title="ENEMY TEAM" accent={[248,113,113]} slots={enemy} r={enemyR}
              onOpen={(i)=>setPicker({team:"enemy",index:i})} onClear={(i)=>clearSlot("enemy",i)}
              onPreset={(k)=>loadPreset("enemy",k)} onClear2={()=>clearAll("enemy")} />
          </div>
        )}

        {view==="matrix" && <MatrixView/>}

        {view==="classes" && <ClassesView/>}

        {view==="dynamics" && <DynamicsView youNames={youNames} enemyNames={enemyNames}/>}

        {view==="matchup" && <MatchupView m={m} youR={youR} enemyR={enemyR} youNames={youNames} enemyNames={enemyNames} goBuild={()=>setView("build")} />}

        {view==="strategy" && (
          <StrategyView youR={youR} enemyR={enemyR} side={stratSide} setSide={setStratSide} m={m} />
        )}
      </div>

      {picker && <Picker role={slotsOf(picker.team)[picker.index].role}
        accent={picker.team==="you"?[52,211,153]:[248,113,113]}
        chosen={new Set(slotsOf(picker.team).map(s=>s.hero).filter(Boolean))}
        current={slotsOf(picker.team)[picker.index].hero}
        onPick={(h)=>assign(picker.team,picker.index,h)} onClose={()=>setPicker(null)} />}
    </div>
  );
}

/* ───────── team panel ───────── */
function TeamPanel({title,accent,slots,r,onOpen,onClear,onPreset,onClear2}){
  const [open,setOpen]=useState(false);
  const tc=TIER_C[r.tier];
  return (
    <div style={{background:"#0b0d12",border:`1px solid ${rgba(accent,0.3)}`,borderRadius:16,padding:15,
      boxShadow:`inset 0 0 40px ${rgba(accent,0.05)}`}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
        <div style={{fontSize:13,letterSpacing:2,fontWeight:700,color:rgb(accent)}}>{title}</div>
        {r.count>0 && <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontFamily:FONT_M,fontSize:11,color:"#8a93a3"}}>{r.dom||"—"}</span>
          <span style={{fontFamily:FONT_M,fontSize:20,fontWeight:700,color:"#f4f6fa"}}>{r.rating.toFixed(0)}</span>
          <span style={{padding:"1px 9px",borderRadius:6,fontWeight:700,fontSize:12,color:rgb(tc),background:rgba(tc,0.13),border:`1px solid ${rgba(tc,0.4)}`}}>{r.tier}</span>
        </div>}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {slots.map((s,i)=><SlotCard key={i} slot={s} accent={accent} onOpen={()=>onOpen(i)} onClear={()=>onClear(i)} />)}
      </div>
      <div style={{display:"flex",gap:5,flexWrap:"wrap",marginTop:11,alignItems:"center"}}>
        {Object.keys(PRESETS).map(p=><button key={p} onClick={()=>onPreset(p)} style={miniBtn}>{p}</button>)}
        <button onClick={onClear2} style={{...miniBtn,color:"#f87171",borderColor:"#3a2226"}}>Clear</button>
      </div>
      {r.count>0 && <>
        <button onClick={()=>setOpen(o=>!o)} style={{...miniBtn,marginTop:10,width:"100%",
          color:"#9aa3b2",display:"flex",justifyContent:"space-between"}}>
          <span>SYNERGY {r.synergyTotal>=0?"+":""}{r.synergyTotal} · {r.log.length} signal{r.log.length!==1?"s":""}</span><span>{open?"▲":"▼"}</span></button>
        {open && <div style={{marginTop:10,display:"flex",flexDirection:"column",gap:8}}>
          {r.log.map((e,i)=>{ const pos=e.pts>=0; const c=pos?[52,211,153]:[248,113,113];
            return <div key={i} style={{display:"flex",gap:9}}>
              <span style={{flexShrink:0,fontFamily:FONT_M,fontSize:11.5,fontWeight:700,width:26,textAlign:"right",color:rgb(c)}}>{pos?"+":""}{e.pts}</span>
              <div style={{borderLeft:`2px solid ${rgba(c,0.5)}`,paddingLeft:9}}>
                <div style={{fontSize:12.5,fontWeight:600,color:"#e7eaf0"}}>{e.label}</div>
                <div style={{fontSize:11,color:"#828b9b",lineHeight:1.4}}>{e.reason}</div></div></div>; })}
          <div style={{marginTop:4,display:"flex",flexWrap:"wrap",gap:"4px 8px"}}>
            {r.axes.map(a=>{const[rr,gg,bb]=heat(a.v);return <span key={a.k} style={{fontFamily:FONT_M,fontSize:10,color:`rgb(${rr},${gg},${bb})`}}>{FLABEL[a.k]} {a.v.toFixed(1)}</span>;})}
          </div>
        </div>}
      </>}
    </div>
  );
}

function SlotCard({slot,accent,onOpen,onClear}){
  const c=ROLE_C[slot.role]; const filled=!!slot.hero; const cpt=filled?comp(HEROES[slot.hero]):0;
  return (
    <div onClick={onOpen} style={{cursor:"pointer",position:"relative",background:filled?"#0e1117":"#090b0f",
      border:`1px solid ${filled?rgba(c,0.4):"#1b1e26"}`,borderRadius:10,padding:"9px 10px",minHeight:72}}>
      <div style={{fontSize:8.5,letterSpacing:1.5,fontWeight:600,color:rgb(c)}}>{slot.role.toUpperCase()}</div>
      {filled?(
        <div style={{display:"flex",alignItems:"center",gap:9,marginTop:5}}>
          <Sigil name={slot.hero} rgb={c} size={36}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:14,fontWeight:700,lineHeight:1.05,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{HEROES[slot.hero].name}</div>
            <div style={{display:"flex",alignItems:"center",gap:6,marginTop:6}}>
              <div style={{flex:1,height:3,borderRadius:9,background:"#1a1d25",overflow:"hidden"}}>
                <div style={{width:`${cpt*10}%`,height:"100%",background:rgb(c)}}/></div>
              <span style={{fontFamily:FONT_M,fontSize:10,color:"#9aa3b2"}}>{cpt.toFixed(1)}</span></div>
          </div>
          <button onClick={(e)=>{e.stopPropagation();onClear();}} style={{position:"absolute",top:6,right:6,width:17,height:17,
            lineHeight:"14px",textAlign:"center",borderRadius:5,border:"1px solid #23262e",background:"#10131a",color:"#6b7280",cursor:"pointer",fontSize:10}}>✕</button>
        </div>
      ):<div style={{marginTop:9,color:"#5b6270",fontSize:12,fontWeight:500}}>+ {slot.role}</div>}
    </div>
  );
}

function Picker({role,accent,chosen,current,onPick,onClose}){
  const c=ROLE_C[role];
  return (
    <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:50,background:"rgba(3,4,6,0.72)",backdropFilter:"blur(3px)",
      display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
      <div onClick={e=>e.stopPropagation()} className="pk" style={{width:"100%",maxWidth:420,maxHeight:"80vh",overflowY:"auto",
        background:"#0c0e13",border:`1px solid ${rgba(accent,0.4)}`,borderRadius:16,padding:14,
        boxShadow:`0 20px 60px rgba(0,0,0,.6), inset 0 0 30px ${rgba(accent,0.06)}`}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{fontSize:13,letterSpacing:2,fontWeight:700,color:rgb(c)}}>SELECT {role.toUpperCase()}</div>
          <button onClick={onClose} style={{...ghostBtn,padding:"5px 10px"}}>✕</button></div>
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          {BY_ROLE[role].map(n=>{ const taken=chosen.has(n)&&n!==current; const cpt=comp(HEROES[n]); const[r,g,b]=heat(cpt); const cur=n===current;
            return <button key={n} disabled={taken} onClick={()=>onPick(n)} style={{display:"flex",alignItems:"center",gap:10,textAlign:"left",
              cursor:taken?"not-allowed":"pointer",background:cur?rgba(c,0.12):"#0a0c10",opacity:taken?0.32:1,
              border:`1px solid ${cur?rgba(c,0.5):"#171a21"}`,borderRadius:9,padding:"8px 11px"}}>
              <Sigil name={n} rgb={c} size={26}/>
              <span style={{flex:1,fontSize:14.5,fontWeight:600,color:"#eef1f6"}}>{n}{taken&&<span style={{fontSize:10,color:"#6b7280",marginLeft:6}}>· picked</span>}</span>
              <span style={{width:60,height:4,borderRadius:9,background:"#1a1d25",overflow:"hidden"}}><span style={{display:"block",width:`${cpt*10}%`,height:"100%",background:`rgb(${r},${g},${b})`}}/></span>
              <span style={{fontFamily:FONT_M,fontSize:11,color:`rgb(${r},${g},${b})`,width:24,textAlign:"right"}}>{cpt.toFixed(1)}</span></button>; })}
        </div>
      </div>
    </div>
  );
}

/* ───────── matchup view ───────── */
function CompStrip({label,accent,names,r}){
  return (
    <div style={{flex:1,minWidth:230}}>
      <div style={{fontSize:10.5,letterSpacing:2,fontWeight:700,color:rgb(accent),marginBottom:6}}>{label} · {r.dom||"—"} · {r.count>0?r.rating.toFixed(0):"—"}</div>
      <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
        {names.filter(Boolean).map(n=>{const c=ROLE_C[HEROES[n].role];
          return <span key={n} style={{display:"inline-flex",alignItems:"center",gap:5,fontSize:12,fontWeight:600,padding:"3px 8px 3px 4px",borderRadius:7,background:rgba(c,0.12),border:`1px solid ${rgba(c,0.35)}`,color:rgb(c)}}><Sigil name={n} rgb={c} size={16}/>{n}</span>;})}
        {names.filter(Boolean).length===0 && <span style={{color:"#5b6270",fontSize:12}}>empty</span>}
      </div>
    </div>
  );
}

function MatchupView({m,youR,enemyR,youNames,enemyNames,goBuild}){
  const ready=youR.count>0&&enemyR.count>0;
  const vc=VERD_C[m.verdict]||[148,156,168];
  const favor=m.edges.filter(e=>e.pts>0), threat=m.edges.filter(e=>e.pts<0), neutral=m.edges.filter(e=>e.pts===0);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:"14px 16px",display:"flex",gap:18,flexWrap:"wrap"}}>
        <CompStrip label="YOUR TEAM" accent={[52,211,153]} names={youNames} r={youR}/>
        <CompStrip label="ENEMY TEAM" accent={[248,113,113]} names={enemyNames} r={enemyR}/>
      </div>

      {!ready ? (
        <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:24,textAlign:"center",color:"#7c8595"}}>
          Build both teams to see the matchup. <button onClick={goBuild} style={{...miniBtn,marginLeft:8}}>Go to Build</button>
        </div>
      ) : (
        <>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:16,alignItems:"stretch"}}>
            {/* verdict */}
            <div style={{background:"#0b0d12",border:`1px solid ${rgba(vc,0.4)}`,borderRadius:14,padding:"18px",
              display:"flex",flexDirection:"column",justifyContent:"center",boxShadow:`inset 0 0 40px ${rgba(vc,0.07)}`}}>
              <div style={{fontSize:10.5,letterSpacing:2,color:"#6b7280"}}>YOUR MATCHUP</div>
              <div style={{fontSize:26,fontWeight:700,letterSpacing:0.5,color:rgb(vc),margin:"4px 0 10px",lineHeight:1.05}}>{m.verdict}</div>
              <SignedBar label="EDGE" val={m.edge}/>
              <div style={{fontSize:11.5,color:"#828b9b",marginTop:10,lineHeight:1.5}}>
                Net of the comp triangle and every counter the engine detects, from your side.
              </div>
            </div>
            {/* triangle */}
            <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:"12px",display:"flex",flexDirection:"column",alignItems:"center"}}>
              <div style={{fontSize:10.5,letterSpacing:2,color:"#6b7280",alignSelf:"flex-start",marginBottom:2}}>COMP TRIANGLE</div>
              <Triangle yd={m.yd} ed={m.ed}/>
              <div style={{fontSize:10.5,color:"#6b7280",fontFamily:FONT_M}}>arrow = "beats"</div>
            </div>
          </div>

          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",gap:16}}>
            <EdgeList title="IN YOUR FAVOR" color={[52,211,153]} items={favor} empty="No clear advantages — even ground." />
            <EdgeList title="THREATS TO ANSWER" color={[248,113,113]} items={threat} empty="No glaring weaknesses against this comp." />
          </div>
          {neutral.length>0 && <div style={{fontSize:12,color:"#8a93a3",fontFamily:FONT_M,textAlign:"center"}}>◦ {neutral[0].reason}</div>}
        </>
      )}
    </div>
  );
}

function EdgeList({title,color,items,empty}){
  return (
    <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:"15px 17px"}}>
      <div style={{fontSize:10.5,letterSpacing:2,color:rgb(color),marginBottom:12,fontWeight:700}}>{title}</div>
      {items.length===0 && <div style={{color:"#5b6270",fontSize:12.5}}>{empty}</div>}
      <div style={{display:"flex",flexDirection:"column",gap:10}}>
        {items.map((e,i)=>(
          <div key={i} style={{display:"flex",gap:10}}>
            <span style={{flexShrink:0,fontFamily:FONT_M,fontSize:12,fontWeight:700,width:28,textAlign:"right",color:rgb(color)}}>{e.pts>0?"+":""}{e.pts}</span>
            <div style={{borderLeft:`2px solid ${rgba(color,0.5)}`,paddingLeft:10}}>
              <div style={{fontSize:13,fontWeight:600,color:"#e7eaf0"}}>{e.label}</div>
              <div style={{fontSize:11.5,color:"#828b9b",lineHeight:1.45}}>{e.reason}</div></div>
          </div>))}
      </div>
    </div>
  );
}

function Triangle({yd,ed}){
  const P={Dive:[110,30],Brawl:[30,150],Poke:[190,150]};
  const arrows=[["Dive","Poke"],["Poke","Brawl"],["Brawl","Dive"]]; // source beats target
  const nodeColor=(k)=> k===yd?[52,211,153]: k===ed?[248,113,113]:[60,66,78];
  const trim=(a,b,r)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy);return [a[0]+dx/L*r,a[1]+dy/L*r];};
  return (
    <svg viewBox="0 0 220 180" width="200" height="164">
      <defs><marker id="ah" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <path d="M0,0 L6,3 L0,6 Z" fill="#3a4150"/></marker>
      <marker id="ahh" markerWidth="9" markerHeight="9" refX="6" refY="3" orient="auto">
        <path d="M0,0 L6,3 L0,6 Z" fill="#34d399"/></marker></defs>
      {arrows.map(([s,t],i)=>{
        const a=trim(P[s],P[t],30), b=trim(P[t],P[s],32);
        const active = (s===yd&&t===ed);
        return <line key={i} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]}
          stroke={active?"#34d399":"#262b34"} strokeWidth={active?2.2:1.4}
          markerEnd={active?"url(#ahh)":"url(#ah)"} opacity={active?1:0.8}/>;
      })}
      {Object.entries(P).map(([k,[x,y]])=>{ const c=nodeColor(k); const isYou=k===yd,isEn=k===ed;
        return <g key={k}>
          <circle cx={x} cy={y} r={26} fill={rgba(c,(isYou||isEn)?0.16:0.06)} stroke={rgb(c)} strokeWidth={(isYou||isEn)?2:1}/>
          <text x={x} y={y-1} textAnchor="middle" fontFamily={FONT_D} fontSize="11" fontWeight="700" fill={rgb(c)}>{k.toUpperCase()}</text>
          {(isYou||isEn) && <text x={x} y={y+11} textAnchor="middle" fontFamily={FONT_M} fontSize="7.5" fill={rgb(c)}>{isYou?"YOU":"ENEMY"}</text>}
        </g>; })}
    </svg>
  );
}

/* ───────── strategy view ───────── */
function StrategyView({youR,enemyR,side,setSide,m}){
  const r = side==="you"?youR:enemyR;
  const accent = side==="you"?[52,211,153]:[248,113,113];
  const opp = side==="you"?enemyR:youR;
  const strat = (r.dom&&STRATEGY[r.dom])?STRATEGY[r.dom]:FALLBACK;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{display:"flex",gap:6,alignItems:"center"}}>
        <span style={{fontSize:10.5,letterSpacing:2,color:"#6b7280",marginRight:2}}>GAME PLAN FOR</span>
        {[["you","YOUR TEAM",[52,211,153]],["enemy","ENEMY TEAM",[248,113,113]]].map(([v,l,c])=>{
          const a=side===v;
          return <button key={v} onClick={()=>setSide(v)} style={{border:`1px solid ${a?rgba(c,0.5):"#1b1e26"}`,cursor:"pointer",
            padding:"7px 13px",borderRadius:8,fontFamily:FONT_D,fontSize:12.5,fontWeight:600,letterSpacing:0.6,
            background:a?rgba(c,0.12):"transparent",color:a?rgb(c):"#727b8a"}}>{l}</button>;})}
      </div>

      <div style={{background:"#0b0d12",border:`1px solid ${rgba(accent,0.3)}`,borderRadius:16,padding:"18px 20px",
        boxShadow:`inset 0 0 40px ${rgba(accent,0.05)}`}}>
        <div style={{display:"flex",alignItems:"baseline",gap:10,flexWrap:"wrap"}}>
          <h2 style={{margin:0,fontSize:24,fontWeight:700,letterSpacing:0.5,color:rgb(accent)}}>{r.dom||"NO IDENTITY"}</h2>
          <span style={{fontSize:13,color:"#9aa3b2"}}>{strat.tag}</span>
        </div>

        <div style={{marginTop:16,fontSize:11,letterSpacing:2,color:"#34d399",fontWeight:700}}>▸ GAME PLAN — PLAY TO THIS</div>
        <ul style={{margin:"9px 0 0",paddingLeft:18,lineHeight:1.6}}>
          {strat.plan.map((p,i)=><li key={i} style={{fontSize:13.5,color:"#d7dce4",marginBottom:6}}>{p}</li>)}
        </ul>

        <div style={{marginTop:18,fontSize:11,letterSpacing:2,color:"#f87171",fontWeight:700}}>▸ SETBACKS — WHAT INHIBITS IT</div>
        <ul style={{margin:"9px 0 0",paddingLeft:18,lineHeight:1.6}}>
          {strat.set.map((p,i)=><li key={i} style={{fontSize:13.5,color:"#cdd3dd",marginBottom:6}}>{p}</li>)}
        </ul>
      </div>

      {youR.count>0&&enemyR.count>0&&r.dom&&opp.dom && (
        <div style={{background:"#0b0d12",border:"1px solid #1b1e26",borderRadius:14,padding:"14px 17px"}}>
          <div style={{fontSize:10.5,letterSpacing:2,color:"#6b7280",marginBottom:7}}>AGAINST THE OTHER COMP ({opp.dom})</div>
          <div style={{fontSize:13.5,color:"#d7dce4",lineHeight:1.55}}>
            {matchupTip(r.dom,opp.dom)}
          </div>
        </div>
      )}
    </div>
  );
}
function matchupTip(me,them){
  if(BEATS[me]===them) return `The triangle favors you here — your ${me} naturally pressures their ${them}. Lean into it: play your strengths fast before they can stabilize.`;
  if(BEATS[them]===me) return `The triangle is against you — their ${them} pressures your ${me}. You'll need to break the script: deny their core tools, win off-angles, and avoid fighting on their terms.`;
  return `${me} mirror — no triangle edge. Map control, ult tracking, and cleaner execution decide it.`;
}

const ghostBtn={background:"transparent",border:"1px solid #23262e",color:"#9aa3b2",padding:"7px 13px",borderRadius:8,fontFamily:FONT_D,fontSize:12,cursor:"pointer",letterSpacing:1};
const miniBtn={background:"transparent",border:"1px solid #1b1e26",color:"#aab2c0",padding:"6px 10px",borderRadius:7,fontFamily:FONT_M,fontSize:11,cursor:"pointer",letterSpacing:0.3};

function Bar({label,val,max,color}){ return (
  <div><div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
    <span style={{fontSize:11,letterSpacing:1.5,color:"#7c8595"}}>{label}</span>
    <span style={{fontFamily:FONT_M,fontSize:13,color:"#e7eaf0"}}>{val.toFixed(1)}</span></div>
  <div style={{height:8,borderRadius:9,background:"#15181f",overflow:"hidden"}}><div style={{width:`${(val/max)*100}%`,height:"100%",borderRadius:9,background:color}}/></div></div>); }

function SignedBar({label,val}){
  const pos=val>=0; const col=pos?"rgb(52,211,153)":"rgb(248,113,113)"; const pct=Math.min(50,(Math.abs(val)/20)*50);
  return (<div><div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
    <span style={{fontSize:11,letterSpacing:1.5,color:"#7c8595"}}>{label}</span>
    <span style={{fontFamily:FONT_M,fontSize:13,color:col}}>{pos?"+":""}{val}</span></div>
  <div style={{position:"relative",height:8,borderRadius:9,background:"#15181f",overflow:"hidden"}}>
    <div style={{position:"absolute",left:"50%",top:0,bottom:0,width:1,background:"#2a2e38"}}/>
    <div style={{position:"absolute",top:0,bottom:0,background:col,borderRadius:9,...(pos?{left:"50%",width:`${pct}%`}:{right:"50%",width:`${pct}%`})}}/>
  </div></div>);
}
