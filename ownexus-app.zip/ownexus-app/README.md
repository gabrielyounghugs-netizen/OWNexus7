# OWNexus — Overwatch Team Hub & Strategy Study

Single-page React (Vite) app: hero matrix, team builder, synergy + matchup engine,
sub-role classification, dynamics graph (relationship web + combo chains), and strategy guides.
All logic and data live in `src/App.jsx`. No backend, no API keys.

## Develop
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # -> dist/
npm run preview
```

## Deploy to Vercel — pick ONE
**A) CLI:** `npm i -g vercel` → `vercel` (log in, accept Vite defaults) → `vercel --prod`
**B) Git:** push to GitHub → vercel.com → Add New → Project → import → Deploy (auto-detects Vite)
**C) Prebuilt:** `dist/` is already built → `vercel deploy --prebuilt --prod` or drag-drop in dashboard

## After your first deploy — fix the social image URL
The Open Graph / Twitter tags in `index.html` point at `https://ownexus.vercel.app/`.
If your real domain differs, replace that domain in the four `og:`/`twitter:` lines so
link previews (Discord, Twitter, iMessage) show `og.png` correctly.

## Branding assets (in `public/`)
- `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`, `icon-512.png` — generated OWNexus seal
- `og.png` — 1200×630 social preview
- `site.webmanifest` — installable PWA metadata

## Customize
- Hero data / scores / traits / sub-roles / combos: top of `src/App.jsx`.
- Swap generated sigils for real art: `ART["Genji"] = "/heroes/genji.png"` (drop images in `public/`).
